﻿// ConsoleApplication1222.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
class Animal {
	char *name;
public:
	Animal() {
		name = new char[50];
		std::cout << "Animal\n";
	}
	/*virtual */~Animal() {
		delete name;
		std::cout << "~Animal\n";
	}
	virtual void say() = 0;
};
class Cat : public Animal {
public:
	Cat() {
		std::cout << "Cat\n";
		color = new char[50];
	}
	~Cat() {
		std::cout << "~Cat\n";
		free(color);
	}
	virtual void say() {
		std::cout << "meow\n";
	}
protected:
	char *color;
};
int main() {
	Animal* p = new Cat();
	p->say();
	//delete p;
	return 0;
}